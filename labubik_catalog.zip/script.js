// Small JS: no-op for now; content is static
document.addEventListener('DOMContentLoaded', ()=>{});
